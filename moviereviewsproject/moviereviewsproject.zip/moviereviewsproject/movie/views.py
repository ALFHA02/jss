from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

from .models import Movie


def home(request):
    search = request.GET.get('searchMovie')

    if search:
        movies = Movie.objects.filter(title__icontains=search)
    else:
        movies = Movie.objects.all()

    return render(request, 'home.html', {'movies': movies})

    # return HttpResponse("<h2>Hola Django</h2>")
    

    # print('buscar:', search)
    # buscar en la base de datos de peliculas
    # return render(request, 'home.html', {'nombre': 'César', 'apellido': 'Alcívar'})



def about(request):
    return render(request, 'about.html')
